function SocialLinks() {
  return <div>SocialLinks</div>;
}

export default SocialLinks;
