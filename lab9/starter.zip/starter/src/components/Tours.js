function Tours() {
  return (
    <div>
      <p className="section-dummy">Tours</p>
      <p className="section-dummy">...</p>
    </div>
  );
}

export default Tours;
