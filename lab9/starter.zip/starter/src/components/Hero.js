function Hero() {
  return (
    <div>
      <p className="section-dummy">Hero</p>
      <p className="section-dummy">...</p>
    </div>
  );
}

export default Hero;
