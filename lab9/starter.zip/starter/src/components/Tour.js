function Tour() {
  return <div>Tour</div>;
}

export default Tour;
