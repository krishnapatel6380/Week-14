function SocialLink() {
  return <div>SocialLink</div>;
}

export default SocialLink;
