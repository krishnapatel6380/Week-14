function PageLink() {
  return <div>PageLink</div>;
}

export default PageLink;
