function Title() {
  return (
    <div>
      <p className="section-dummy">Text</p>
      <p className="section-dummy">Text</p>
    </div>
  );
}

export default Title;
