function Services() {
  return (
    <div>
      <p className="section-dummy">Services</p>
      <p className="section-dummy">...</p>
    </div>
  );
}

export default Services;
