function Service() {
  return <div>Service</div>;
}

export default Service;
