const About = () => {
  return (
    <div>
      <p className="section-dummy">About</p>
      <p className="section-dummy">...</p>
    </div>
  );
};
export default About;
